<nav id="sideNav">
        <ul>
            <li><a href="index.php">1. <br> Home</a></li>
            <li><a href="about.php">2. <br> About</a></li>
            <li><a href="experience.php">3. <br> Experience</a></li>
            <li><a href="project.php">4. <br> Projects</a></li>
            <li><a href="contact.php">5. <br> Contact</a></li>
            <div class="button" id="button-5">
                <div id="translate"></div>
                <a href="#">Resume</a>
            </div>
        </ul>
</nav>
<i id="menuBtn" class="fa-sharp fa-solid fa-bars"></i>
