    <footer>
            <div class="social-icons" >
                <a href="https://www.facebook.com/rashed.shaon" target="_blank"><i class="fa-brands fa-square-facebook"></i></a>
                <a href="https://www.instagram.com/tahsenshaon/" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                <a href="https://github.com/Tahsen22" target="_blank"><i class="fa-brands fa-square-github"></i></a>
                <a href="https://www.linkedin.com/in/tahsen-shaon/" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
            </div>
            <div
                class="text-center p-3"
                style="background-color: #030630; color: aliceblue;"
                >
            © <?php echo date('Y') ?> Copyright:
            <a class="studio-link" href="" target="_blank" style="font-weight: bolder; text-decoration: none;
            color: aliceblue;">Tahsen Studio</a>
            </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.0/typed.min.js"></script>
    <script src="./assets/script.js"></script>
</body>
</html>