<?php
    // connect to db
    $servername = "localhost";
    $username = "root";
    $dbpassword = "";
    $dbname = "finalprojectphp";
    $conn = new mysqli($servername, $username, $dbpassword, $dbname);
    if ($conn->connect_errno) {
        die("Connection failed: " . $conn->connect_error);
    }
?>
