<?php
    include './includes/head.php';
?>

<body>
     <!-- START CONTACT SECTION -->
    <section id="header" class="contact-form" style="height: 70%;">
        <div class="container">
            <div class="section-contact">
              <div class="row justify-content-center">
                  <div class="col-12">
                      <div class="header-section text-center">
                          <h2 class="title">Registration for free Quotation 
                            <br> & 
                            <br> 20% off for first time service.
                          </h2>
                      </div>
                  </div>
              </div>
              <div class="form-contact">
                  <form action="./contactProcess.php" method="post">
                      <div class="row">
                            <div class="col-12">
                                <div class="single-input">
                                    <input type="text" class="form-control" name="firstName" id="firstName" placeholder="First NAME" required="">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="single-input">
                                    <input type="text" class="form-control" name="lastName" id="lastName" placeholder="Last NAME" required="">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="single-input">
                                  <input type="email" class="form-control" name="email" id="Sender" placeholder="EMAIL" required="">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="single-input">
                                  <input type="phone" class="form-control" name="phone" id="Sender" placeholder="PHONE NUMBER" required="">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="single-input">
                                  <input type="password" class="form-control" name="password" id="Sender" placeholder="PASSWORD" required="">
                                </div>
                            </div>
                            <div class="col-12">
                            <div class="d-grid gap-2 single-input">
                                <button class="btn btn-primary" type="submit"
                                style="background-color: #2bd6a0;">Registration</button>
                            </div>              
                            
                      </div>
                  </form>
              </div>
            </div>
          </div>
          
    </section>

<!-- Side Nav php -->
<!-- Footer php -->
<!-- Java script and jQuery -->
<?php
    include './includes/sidenav.php';
    include './includes/footer.php';
?>