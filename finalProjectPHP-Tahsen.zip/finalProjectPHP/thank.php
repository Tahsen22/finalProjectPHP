<?php
    include './includes/head.php';
    session_start();
?>
<section id="header" class="contact-form" style="height: 70%;">
        <div class="container">
            <div class="section-contact">
              <div class="row justify-content-center">
                  <div class="col-12">
                    <div>
                        <h2 style="color:aliceblue">Thank You for sending your message 
                        <?php echo ucwords($_SESSION["fullName"]) . "."; ?></h2>
                        <h2 style="color:aquamarine">We will contact with You very soon.</h2>
                    </div>
              </div>
            </div>
          </div>     
    </section>
    <section class="page-section" id="experience" >
        <div class="container" id="education">
            <div class="row">
                <div class="col">
                    <h5>Address</h5>
                    <hr>
                    <p>104 Goodwood Park Court<br>
                    East York, ON. Canada<br>
                    M4C 2G9
                </p>  
                </div>
                <div class="col">
                    <h5>Phone Number</h5>
                    <hr>
                    <p>+1 437 776 6686</p>
                </div>
                <div class="col">
                    <h5>Email</h5>
                    <hr>
                    <p>tahsen.rashed@gmail.com</p>
                </div>
            </div>
            <hr style="margin-bottom: 40px;">
        </div>
        
    </section>

<!-- Side Nav php -->
<!-- Footer php -->
<!-- Java script and jQuery -->
<?php
    include './includes/sidenav.php';
    include './includes/footer.php';
?>