<?php
    include './includes/head.php';
?>

<section id="project" class="content-blog">
    <div class="head-container">
        <h1 style="text-align:center; margin-top: 20px; font-size: 40px;">PROJECTS AND TECHNOLOGY</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-12">
                <h2 class="titel -border"></h2>
                <article class="card-post">
                    <a href="" class="link"></a>
                    <div class="box-img">
                        <img src="./assets/advanceWeb.jpg" alt="">
                    </div>
                    <div class="box-content">
                        <h4 style="color:aquamarine; margin-top: 20px;">Website : blogCANADA</h4>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
                            Quibusdam, obcaecati ipsa facere iste, labore, 
                            debitis eveniet explicabo optio omnis similique 
                            tenetur nulla ea neque doloribus quae a sequi! Aperiam 
                            labore suscipit possimus asperiores natus pariatur?
                        </p>
                    </div>
                </article>
                <a href="advanceWebDevlopment.html" class="load">Project Details with Video</a>
            </div>
            <aside class="col-lg-4 col-12">
                <h2 class="titel -border"></h2>
                <div class="box -box-tag">
                    <h4>Advance Web Devlopment</h4>
                    <ul class="tags">
                        <li><a href="">HTML5</a></li>
                        <li><a href="">CSS3</a></li>
                        <li><a href="">JAVA SCRIPT</a></li>
                        <li><a href="">Font Awesome</a></li>
                        <li><a href="">Bootstrap5</a></li>
                        <li><a href="">Google Font</a></li>
                    </ul>
                </div>
            </aside>
        </div>
        <div class="row">
            <div class="col-lg-8 col-12">
                <h2 class="titel -border"></h2>
                <article class="card-post">
                    <a href="" class="link"></a>
                    <div class="box-img">
                        <img src="./assets/asp.netMVC.jpg" alt="">
                    </div>
                    <div class="box-content">
                        <h4 style="color:aquamarine; margin-top: 20px;">Website : A photography studio</h4>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
                            Quibusdam, obcaecati ipsa facere iste, labore, 
                            debitis eveniet explicabo optio omnis similique 
                            tenetur nulla ea neque doloribus quae a sequi! Aperiam 
                            labore suscipit possimus asperiores natus pariatur?
                        </p>
                    </div>
                </article>
                <a href="article.html" class="load">Project Details with Video</a>
            </div>
            <aside class="col-lg-4 col-12">
                <h3 class="titel -border"></h3>
                <div class="box -box-tag">
                    <h4>ASP.NET in MVC environment</h4>
                    <ul class="tags">
                        <li><a href="">HTML5</a></li>
                        <li><a href="">CSS3</a></li>
                        <li><a href="">JAVA SCRIPT</a></li>
                        <li><a href="">ASP.NET MVC</a></li>
                        <li><a href="">Font Awesome</a></li>
                        <li><a href="">Bootstrap5</a></li>
                        <li><a href="">Google Font</a></li>
                    </ul>
                </div>
            </aside>
        </div>
        <div class="row">
            <div class="col-lg-8 col-12">
                <h2 class="titel -border"></h2>
                <article class="card-post">
                    <a href="" class="link"></a>
                    <div class="box-img">
                        <img src="./assets/c++Devlopment.jpg" alt="">
                    </div>
                    <div class="box-content">
                        <h4 style="color:aquamarine; margin-top: 20px;">Website : THE GHOROYA (A Local Restaurent)</h4>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
                            Quibusdam, obcaecati ipsa facere iste, labore, 
                            debitis eveniet explicabo optio omnis similique 
                            tenetur nulla ea neque doloribus quae a sequi! Aperiam 
                            labore suscipit possimus asperiores natus pariatur?
                        </p>
                    </div>
                </article>
                <a href="#" class="load">Project Details with Video</a>
            </div>
            <aside class="col-lg-4 col-12">
                <h3 class="titel -border"></h3>
                <div class="box -box-tag">
                    <h4>C++ Devlopment with mySQL SERVER</h4>
                    <ul class="tags">
                        <li><a href="">HTML5</a></li>
                        <li><a href="">CSS3</a></li>
                        <li><a href="">jQuery</a></li>
                        <li><a href="">mySQL SERVER Object</a></li>
                        <li><a href="">Font Awesome</a></li>
                        <li><a href="">Bootstrap CSS</a></li>
                        <li><a href="">Bootstrap JS</a></li>
                    </ul>
                </div>
            </aside>
        </div>
        <div class="row">
            <div class="col-lg-8 col-12">
                <h2 class="titel -border"></h2>
                <article class="card-post">
                    <a href="" class="link"></a>
                    <div class="box-img">
                        <img src="./assets/gameAppWindows10.jpg" alt="">
                    </div>
                    <div class="box-content">
                        <h4 style="color:aquamarine; margin-top: 20px;">Website : Tic-tac-toe (A gaming app)</h4>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
                            Quibusdam, obcaecati ipsa facere iste, labore, 
                            debitis eveniet explicabo optio omnis similique 
                            tenetur nulla ea neque doloribus quae a sequi! Aperiam 
                            labore suscipit possimus asperiores natus pariatur?
                        </p>
                    </div>
                </article>
                <a href="#" class="load">Project Details with Video</a>
            </div>
            <aside class="col-lg-4 col-12">
                <h3 class="titel -border"></h3>
                <div class="box -box-tag">
                    <h4>C++ Universal Windows </h4>
                    <ul class="tags">
                        <li><a href="">VIEW.XAML</a></li>
                        <li><a href="">XAML.CS</a></li>
                        <li><a href="">jQuery</a></li>
                        <li><a href="">Windows.UI.Xaml.Media</a></li>
                        <li><a href="">Windows.UI.Xaml.Data</a></li>
                        <li><a href="">Many more Library</a></li>
                    </ul>
                </div>
            </aside>
        </div>
        <div class="row">
            <div class="col-lg-8 col-12">
                <h2 class="titel -border"></h2>
                <article class="card-post">
                    <a href="" class="link"></a>
                    <div class="box-img">
                        <img src="./assets/jQuery.jpg" alt="">
                    </div>
                    <div class="box-content">
                        <h4 style="color:aquamarine; margin-top: 20px;">Website : Fatma (Portfolio for a digital marketing specialist)</h4>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
                            Quibusdam, obcaecati ipsa facere iste, labore, 
                            debitis eveniet explicabo optio omnis similique 
                            tenetur nulla ea neque doloribus quae a sequi! Aperiam 
                            labore suscipit possimus asperiores natus pariatur?
                        </p>
                    </div>
                </article>
                <a href="#" class="load">Project Details with Video</a>
            </div>
            <aside class="col-lg-4 col-12">
                <h3 class="titel -border"></h3>
                <div class="box -box-tag">
                    <h4>JQuery and CMS Development</h4>
                    <ul class="tags">
                        <li><a href="">HTML5</a></li>
                        <li><a href="">CSS3</a></li>
                        <li><a href="">jQuery</a></li>
                        <li><a href="">angularJS</a></li>
                        <li><a href="">REACT</a></li>
                        <li><a href="">BABEL</a></li>
                        <li><a href="">TYPED.JS</a></li>
                        <li><a href="">VUE.JS</a></li>
                        <li><a href="">ANIME.JS</a></li>
                        <li><a href="">AJAX</a></li>
                        <li><a href="">NG App</a></li>
                        <li><a href="">Font Awesome</a></li>
                        <li><a href="">Bootstrap 5</a></li>
                    </ul>
                </div>
            </aside>
        </div>
        <div class="row">
            <div class="col-lg-8 col-12">
                <h2 class="titel -border"></h2>
                <article class="card-post">
                    <a href="" class="link"></a>
                    <div class="box-img">
                        <img src="./assets/linaxApache.jpg" alt="">
                    </div>
                    <div class="box-content">
                        <h4 style="color:aquamarine; margin-top: 20px;">Website : Scarborough Folk Fest (an annual multicultural event)</h4>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
                            Quibusdam, obcaecati ipsa facere iste, labore, 
                            debitis eveniet explicabo optio omnis similique 
                            tenetur nulla ea neque doloribus quae a sequi! Aperiam 
                            labore suscipit possimus asperiores natus pariatur?
                        </p>
                    </div>
                </article>
                <a href="#" class="load">Project Details with Video</a>
            </div>
            <aside class="col-lg-4 col-12">
                <h3 class="titel -border"></h3>
                <div class="box -box-tag">
                    <h4>Linux and Apache</h4>
                    <ul class="tags">
                        <li><a href="">HTML5</a></li>
                        <li><a href="">CSS3</a></li>
                        <li><a href="">jQuery</a></li>
                        <li><a href="">Font Awesome</a></li>
                        <li><a href="">Bootstrap 5</a></li>
                    </ul>
                </div>
            </aside>
        </div>
        
    </div>     
</section>

<!-- Side Nav php -->
<!-- Footer php -->
<!-- Java script and jQuery -->
<?php
    include './includes/sidenav.php';
    include './includes/footer.php';
?>