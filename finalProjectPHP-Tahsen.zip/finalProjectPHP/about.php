<?php
    include './includes/head.php';
?>

<section id="about-header">
<div class="container">
    <div class="row">
        <div class="col-lg-4 mt-5 mb-3">
        <img src="./assets/tahsen.jpg" class="img-flude img-thumbnail" alt="profile picture" style="border-radius: 50%; width: 300px;">
        </div>
        <div class="col-md-6 mt-5 mb-3">
        <h2 class="user-name" style="color:aquamarine; margin-bottom: 10px; text-align: left;">Tahsen Shaon</h2>
        <p style="color: #fff; font-size: 16px; text-align: left;">Lorem ipsum dolor sit amet consectetur 
            adipisicing elit. Consequuntur illum eius 
            obcaecati dolore eaque fugiat exercitationem, 
            magnam sit facilis alias officia, aliquid 
            optio ipsum sint quibusdam rem asperiores 
            cum sed perspiciatis quod rerum velit facere 
            quam? 
            <br>Minima expedita debitis nobis 
            reprehenderit mollitia nihil, repellendus 
            magnam perspiciatis quam, in est doloribus!</p>
        <div class="about-line">
            <span class="line-4"></span><br>
            <span class="line-5"></span><br>
        </div>
        </div>
    </div>
</div>
<div class="container">
    <h3 style="text-align: right; color:aquamarine; padding-top: 60px;">Skills</h3>
    <div class="bar learning" data-skill="mongoDB"></div>
    <div class="bar learning" data-skill="Python"></div>
    <div class="bar back intermediate" data-skill="C#"></div>
    <div class="bar back intermediate" data-skill="ASP.NET"></div>
    <div class="bar learning" data-skill="android & ios Devlopment"></div>
    <div class="bar back intermediate" data-skill="javascript"></div>
    <div class="bar front expert" data-skill="CSS3"></div>
    <div class="bar front expert" data-skill="HTML5"></div>
    <div class="bar front expert" data-skill="Adobe suite"></div>
    <div class="bar back intermediate" data-skill="Photography"></div>
</div>        
<div style="padding:0 20px 0 40px;"><span class="line-6"></span></div>
</section>

<!-- Side Nav php -->
<!-- Footer php -->
<!-- Java script and jQuery -->
<?php
    include './includes/sidenav.php';
    include './includes/footer.php';
?>