var menuBtn = document.getElementById("menuBtn")
var sideNav = document.getElementById("sideNav")

sideNav.style.right = "-250px";
menuBtn.onclick = function () {
    if(sideNav.style.right == "-250px") {
        sideNav.style.right = "0";
    }
    else {
        sideNav.style.right = "-250px";
    }
}

// typed
var typed = new Typed("#element", {
    strings: ["Frontend Development", "Backend Development", "Mobile App Development", "Visual artist", "Photography" ],
    smartBackspace:true,
    typeSpeed:100,
    backSpeed:100,
    loop:true,
    loopCount:Infinity,
    startDelay:1000
});
