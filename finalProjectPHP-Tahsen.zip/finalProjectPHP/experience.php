<?php
    include './includes/head.php';
?>

<!-- Experiences START -->
<section class="page-section" id="experience">
    <div class="head-container">
        <h1 style="text-align:center; margin-top: 20px; font-size: 40px; color: aliceblue;">Education And Traning</h1>
    </div>

    <div class="container" id="education">
        <div class="row">
            <div class="col">
                <h5>DIPLOMA in <br>Enterprise Web & Mobile Developer</h5>
                <hr>
                <p>triOS College<br>Toronto, CANADA</p>  
            </div>
            <div class="col">
                <h5>DIPLOMA in <br>Graphic Design and Interactive Media</h5>
                <hr>
                <p>Toronto Film School (TFS)<br>Toronto, CANADA</p>
            </div>
            <div class="col">
                <h5>MSS in <br> Sociology</h5>
                <hr>
                <p>National University<br>DHAKA, BANGLADESH</p>
            </div>
        </div>
        <hr style="margin-bottom: 40px;">

        <div class="text-center">
            <h2 class="section-heading text-uppercase">Tahsen's Timeline</h2>
            <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
        </div>
        <ul class="timeline">
            <li>
                <div class="timeline-image"></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4>July 2021 Present</h4>
                        <h4 class="subheading">Apprentice Web Devloper</h4>
                    </div>
                    <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                </div>
            </li>
            <li class="timeline-inverted">
                <div class="timeline-image"></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4>July 2018 - Present</h4>
                        <h4 class="subheading">Visual Artist</h4>
                    </div>
                    <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                </div>
            </li>
            <li>
                <div class="timeline-image"></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4>March 2016 - August 2022</h4>
                        <h4 class="subheading">Cashier<br>Customer Service Maneger<br>Customer Service Associet</h4>
                    </div>
                    <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                </div>
            </li>
            <li class="timeline-inverted">
                <div class="timeline-image"></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4>2006- February 2016</h4>
                        <h4 class="subheading">Journalist<br>Script Writer<br>Creative Writer</h4>
                    </div>
                    <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                </div>
            </li>
                
            <li class="timeline-inverted">
                <div class="timeline-image">
                    <a style="text-decoration:none;"href="">
                        <h4>Tahsen's<br>Resume</h4></a>
                </div>
            </li>
        </ul>
    </div>
</section>

<!-- Side Nav php -->
<!-- Footer php -->
<!-- Java script and jQuery -->
<?php
    include './includes/sidenav.php';
    include './includes/footer.php';
?>