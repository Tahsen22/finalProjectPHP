<?php
    include './includes/head.php';
?>

<body>
     <!-- START CONTACT SECTION -->
    <section id="header" class="contact-form" style="height: 70%;">
        <div class="container">
            <div class="section-contact">
              <div class="row justify-content-center">
                  <div class="col-12">
                      <div class="header-section text-center">
                          <h2 class="title">Contact with 
                              <span class="tahsen">Tahsen</span>
                          </h2>
                      </div>
                  </div>
              </div>
              <div class="form-contact">
                  <form action="./contactProcess.php" method="post">
                      <div class="row">
                          <div class="col-12">
                              <div class="single-input">
                                  <i class="fas fa-user"></i>
                                  <input type="text" class="form-control" name="fullName" id="Name" placeholder="NAME" required="">
                              </div>
                          </div>
                          <div class="col-12">
                                <div class="single-input">
                                  <i class="fas fa-envelope"></i>
                                  <input type="email" class="form-control" name="email" id="Sender" placeholder="EMAIL" required="">
                                </div>
                            </div>
                            <div class="col-12">
                              <div class="single-input">
                                  <i class="fas fa-phone"></i>
                                  <input type="phone" class="form-control" name="phone" id="Sender" placeholder="PHONE NUMBER" required="">
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="single-input">
                                  <i class="fas fa-check"></i>
                                  <input type="text" class="form-control" name="subject" id="Subject" placeholder="SUBJECT" required="">
                                </div>
                            </div>
                            <div class="col-12">
                              <div class="single-input">
                                  <i class="fas fa-comment-dots"></i>
                                  <textarea name="message" class="form-control" placeholder="MESSAGE" id="Message" required=""></textarea>
                              </div>
                            </div>
                          <div class="col-lg-12 text-center" style="padding-top: 40px;">               
                            <input class="btn btn-primary" type="submit" value="SEND" style="background-color: #2bd6a0; width:300px">
                          </div>
                      </div>
                  </form>
              </div>
            </div>
          </div>
          
    </section>
    <section class="page-section" id="experience" >
        <div class="container" id="education">
            <div class="row">
                <div class="col">
                    <h5>Address</h5>
                    <hr>
                    <p>104 Goodwood Park Court<br>
                    East York, ON. Canada<br>
                    M4C 2G9
                </p>  
                </div>
                <div class="col">
                    <h5>Phone Number</h5>
                    <hr>
                    <p>+1 437 776 6686</p>
                </div>
                <div class="col">
                    <h5>Email</h5>
                    <hr>
                    <p>tahsen.rashed@gmail.com</p>
                </div>
            </div>
            <hr style="margin-bottom: 40px;">
        </div>
        
    </section>

<!-- Side Nav php -->
<!-- Footer php -->
<!-- Java script and jQuery -->
<?php
    include './includes/sidenav.php';
    include './includes/footer.php';
?>