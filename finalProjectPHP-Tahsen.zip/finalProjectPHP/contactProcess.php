<?php
    session_start();
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fullName = trim(strtolower($_POST["fullName"]));
        $email = trim(strtolower($_POST["email"]));
        $phone = trim($_POST["phone"]);
        $subjec = trim(strtolower($_POST["subject"]));
        $message = trim($_POST["message"]);

        include './includes/bd.php';

        // insert message in cid table
        $insertQuery = "INSERT INTO message (cid, fullName, email, pnumber, subject, message, date)
        VALUES (null, '$fullName' , '$email' , '$phone' , '$subjec', '$message', current_timestamp())";
        if ($conn->query($insertQuery) === TRUE) {
            echo "New user added successfully";
        }else {
            echo "Error: " . $insertQuery . " " . $conn->error;
        }

        $_SESSION["fullName"] = $fullName;
        $_SESSION["email"] = $email;
        $_SESSION["phone"] = $phone;
        header("location: ./thank.php");  
        
    }
?>